package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * a simple class to hold information about a game
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a game is
 * created.
 * </p>
 * @author coce@snhu.edu / Timothy_Johnson
 */

public class Game extends Entity {
    private static List<Team> teams = new ArrayList<>();

    /**
     * hide the default constructor to prevent creating empty instances.
     */
    @SuppressWarnings("unused")
    private Game() {
    }

    // constructor with identifier and name
    public Game(long id, String name) {
        this.id = id;
        this.name = name;
    }

    // method to uniqueness of team names
    public Team addTeam(String name) {
        // check if a team with the same name already exists in the game
        Team existingTeam = getTeam(name);
        if (existingTeam != null) {
            return existingTeam;
        }

        // if team doesn't exist, create a new one
        GameService tempService = GameService.getGameService();
        Team newTeam = new Team(tempService.getNextTeamId(), name);

        // add the new team to the list of teams
        teams.add(newTeam);
        return newTeam;
    }

    // helper method to get a team by name from the list of teams in the game
    private Team getTeam(String name) {
        for (Team team : teams) {
            if (team.getName().equalsIgnoreCase(name)) {
                return team;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return "Game [id=" + id + ", name=" + name + "]";
    }
}